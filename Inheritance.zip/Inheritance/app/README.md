# linheritance: the game
Laboratory task for the Software Construction course

all the assets included in the project are 100% original

Launch the project from game.jar

